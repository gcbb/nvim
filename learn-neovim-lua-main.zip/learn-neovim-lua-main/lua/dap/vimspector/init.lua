-- /Users/nn/.local/share/nvim/site/pack/packer/start/vimspector
require("keybindings").mapVimspector()
